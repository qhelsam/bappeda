<?php

namespace backend\models\customs;

use backend\models\MbRekeningObyek;

/**
* extend backend\models\MbRekeningObyek
*/
class RekeningObyek extends MbRekeningObyek
{
	
}