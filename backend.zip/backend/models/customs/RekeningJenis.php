<?php

namespace backend\models\customs;

use backend\models\MbRekeningJenis;

/**
* extend backend\models\MbRekeningJenis;
*/
class RekeningJenis extends MbRekeningJenis
{
	
}