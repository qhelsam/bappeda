<?php

namespace backend\models\customs;

use backend\models\MbRekeningRincian;

/**
* extend backend\models\MbRekeningRincian;
*/
class RekeningRinci extends MbRekeningRincian
{
	
}