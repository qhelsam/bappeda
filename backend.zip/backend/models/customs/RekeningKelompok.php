<?php

namespace backend\models\customs;

use backend\models\MbRekeningKelompok;

/**
* extend backend\models\MbRekeningKelompok;
*/
class RekeningKelompok extends MbRekeningKelompok
{
	
}